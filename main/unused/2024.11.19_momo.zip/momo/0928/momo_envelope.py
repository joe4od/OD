import os
import requests
import time
import json
import datetime
import threading
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError as e:
        return False
    return True
headers1= {
    'Host': 'event.momoshop.com.tw',
    'Content-type': 'application/json;charset=utf-8',
    'Origin': 'https://www.momoshop.com.tw',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cookie': 'JSESSIONID=8CB1EDE157E042FF3984A7F9504F9D60; cto_bundle=qhwpj19VcU02dm5UbVpJWDMycmNIVzBDN1RwcW5hWVdoYmdUbnVoaTVqdTMlMkJKWVFWRkx1cXVTNGJjcGpvcWIlMkYlMkZENTV3MiUyQjBmOVZXUW0wbTNSWEVKdVklMkJ2RkRRcDFDY2N2dVFsZTIlMkIzJTJCS0owdkhqRmZIRlplVnVSM3p2ZE1ibW1PVTRi; _atrk_sessidx=11; _atrk_siteuid=ycXQbwKreCh5IEYW; _atrk_ssid=Tv1j6GcmlKdW2F8d7nH68d; _atrk_xuid=65c662f4e335bb8ebec439e60bcbcc92de88f1f2e085f5f351aa51f29e843ec3; _edcid=MjAxNDAxNjY2NzYx; _eds=1700653253; _edvid=fdd04d30-892b-11ee-9530-0d920111747c; _ga_BKEC67VMMG=GS1.1.1700653281.1.1.1700654122.24.0.0; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=4; appier_pv_counterc7279b5af7b77d1=3; appier_utmz=%7B%7D; loginRsult=1; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; bid=40c231c98ce97ff60e22350d6828a758; isBI=1; CM=undefined; CN=undefined; TN=undefined; ck_encust=3201140126667761; isEN=56d213b0a60791ab58cac6989e75806758512f06; _fbp=fb.3.1700653281150.1374435174; _ga=GA1.1.273222894.1700653281; _gcl_au=1.1.1515190177.1700653281; arkLogin=0; _wau=201401666761.35.1',
    'Connection': 'keep-alive',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.2;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:PJRL3BQR0W8N4MKOI8LU;msgID:I2023112218005302BNxSJv8Its;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1700647253730450889;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
    'Referer': 'https://www.momoshop.com.tw/',
    'Content-Length': '78',
    'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
    'x-requested-with': 'XMLHttpRequest',
}

# data_from_api2="""{
#     "edm_npn" : null,
#     "enCustNo" : "3201240186661761",
#     "dt_promo_no" : "D94111200001",
#     "m_promo_no" : "U94111200001",
#     "edm_lpn" : "O7E1i4XGcA0"}
# """

data_from_api2="""{
    "m_promo_no" : "U94111400002",
    "dt_promo_no" : "D94111400001",
    "gift_code" : ""}
"""

info = json.loads(data_from_api2)
def main():
    r1 = requests.post('https://event.momoshop.com.tw/promoMechReg.PROMO',headers=headers1,json=info)
    print(r1.text)
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))

# 執行時間：12,0,59,700000
# True=等待時間到/False=直接開始跑
run_now = True
if run_now == False:
    t4 = datetime.datetime.now()
else:
    today = datetime.datetime.now().strftime("%d")
    months = datetime.datetime.now().strftime("%m")
    years = datetime.datetime.now().strftime("%Y")
    t4 = datetime.datetime(int(years),int(months),int(today),9,59,59,700000)     #搶折扣的時間     *****檢查*****
    print(t4)

while datetime.datetime.now() < t4:
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
    time.sleep(0.1)
    continue
while datetime.datetime.now() >= t4 and datetime.datetime.now() < t4 + datetime.timedelta(seconds=3):
    threads = []
    times = 1
    for i in range(times):
        threads.append(threading.Thread(target = main))
        threads[i].start()
    time.sleep(0.2)
while datetime.datetime.now() > t4 + datetime.timedelta(seconds=10):
    time.sleep(9999)
