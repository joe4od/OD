import os
import requests
import time
import json
import datetime
import threading
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError as e:
        return False
    return True
headers1= {
    'Host': 'event.momoshop.com.tw',
    'Content-type': 'application/json;charset=utf-8',
    'Origin': 'https://www.momoshop.com.tw',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cookie': 'cto_bundle=r4P90F9IcW9BUkZibTh2aGtSY3ZUandHd2VjTVRjN2ZVYkZVeXUzSTB0SEdYdVdDVU4lMkZ0VnZabXdseVFIYTdmVVZRbXltdExUTlpYQVljSU9pSVd0VFRjbXJDUkJoZ0g5UjYwT1VGUVMwcUt4dDBaUFRlQloxRGt4OXVNZFZKUWZLbThk; bid=1cfc18dfe22da0752208d7ba8e981ec3; isBI=1; loginRsult=1; _atrk_sessidx=7; _atrk_siteuid=xLY0s-uVAs3a_S4C; _atrk_ssid=LHF3Gvc24-mesTM46Z436v; _atrk_xuid=b73e6788658f779acd293f710445cdd0b64fb5e7611ead4ac0607f547f3678a7; appier_page_isView_ERlDyPL9yO7gfOb=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_page_isView_c7279b5af7b77d1=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_pv_counterERlDyPL9yO7gfOb=2; appier_pv_counterc7279b5af7b77d1=1; appier_utmz=%7B%7D; JSESSIONID=8D37C90ACBCA9D03F88370C83D2C654D; CM=undefined; CN=undefined; TN=undefined; ck_encust=3202630211563922; isEN=1b646af4309db4422a03a7d30b9949fe25f5a9cb; _eds=1701394319; _edvid=6b700740-8fe9-11ee-8531-d1021fd4c398; _ga_BKEC67VMMG=GS1.1.1701394318.1.1.1701394340.38.0.0; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _fbp=fb.3.1701394331540.2006302378; arkLogin=0; _ga=GA1.1.614730245.1701394319; _gcl_au=1.1.1158076230.1701394319',
    'Connection': 'keep-alive',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.2;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:PJRL3BQR0W8N4MKOI8LU;msgID:I2023112218005302BNxSJv8Its;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1700647253730450889;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
    'Referer': 'https://www.momoshop.com.tw/',
    'Content-Length': '78',
    'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
    'x-requested-with': 'XMLHttpRequest',
}

# data_from_api2="""{
#     "edm_npn" : null,
#     "enCustNo" : "3202630211563922",
#     "dt_promo_no" : "D94111200001",
#     "m_promo_no" : "U94111200001",
#     "edm_lpn" : "O7E1i4XGcA0"}
# """

data_from_api2="""{
    "m_promo_no" : "U94111400002",
    "dt_promo_no" : "D94111400001",
    "gift_code" : ""}
"""

info = json.loads(data_from_api2)
def main():
    r1 = requests.post('https://event.momoshop.com.tw/promoMechReg.PROMO',headers=headers1,json=info)
    print(r1.text)
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))


#True=等待時間到/False=直接開始跑
run_now = True
if run_now == False:
    t4 = datetime.datetime.now()
else:
    today = datetime.datetime.now().strftime("%d")
    months = datetime.datetime.now().strftime("%m")
    years = datetime.datetime.now().strftime("%Y")
    t4 = datetime.datetime(int(years),int(months),int(today),9,59,59,700000)     #搶折扣的時間     *****檢查*****
    print(t4)

while datetime.datetime.now() < t4:
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
    time.sleep(0.1)
    continue
while datetime.datetime.now() >= t4 and datetime.datetime.now() < t4 + datetime.timedelta(seconds=3):
    threads = []
    times = 1
    for i in range(times):
        threads.append(threading.Thread(target = main))
        threads[i].start()
    time.sleep(0.1)
while datetime.datetime.now() > t4 + datetime.timedelta(seconds=10):
    time.sleep(9999)
