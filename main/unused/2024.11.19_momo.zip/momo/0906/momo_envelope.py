import os
import requests
import time
import json
import datetime
import threading
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError as e:
        return False
    return True
headers1= {
    'Host': 'event.momoshop.com.tw',
    'Content-type': 'application/json;charset=utf-8',
    'Origin': 'https://www.momoshop.com.tw',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cookie': '_edcid=MjAxNjA4NDkxOTI0; _eds=1701393081; _edvid=571154f0-8faa-11ee-974d-bbfc4160fefa; _ga_BKEC67VMMG=GS1.1.1701393935.1.1.1701394174.10.0.0; _atrk_sessidx=17; _atrk_siteuid=fqWX6qk-cp4lHzAY; _atrk_ssid=jmFLvhHcvhdXPlwk9624_U; _atrk_xuid=dfdbfd4bad38bf0483d42526dd386a29613ca4c225529b496311c079099519b2; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=7; appier_pv_counterc7279b5af7b77d1=6; appier_utmz=%7B%7D; loginRsult=1; arkLogin=; cto_bundle=R_elml9ZN05iQWhNcE1kWWF0NEEyblFCaVJ2RjVSNkRIZkRaRGdIYzhKREtTMzJ4TURBJTJGJTJCNmFUUU5JQXZsakFaQXlJVFE5cWJJcWtydExWTDcyaXZRTTF0cDlCZFBoMVlQd1I4S1A3Q0N1cjZIbDkzUEFsUGxDeWNCVkNiUDF4YUllZU0; JSESSIONID=2EDB39B012AE96007A0E27F06CC98900; ck_encust=3202930231507623; isEN=5303cbb9a7beeb85e4d554acf7ee7c2724b1aa2b; bid=0e7319daf4395874401c6d36bac66b70; isBI=1; isTN1=1; st=a9d90c2789a5601e03e3d9c0e7bb0785; CM=undefined; CN=undefined; TN=undefined; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _fbp=fb.3.1701393935268.1383758280; _ga=GA1.1.305863393.1701393935; _gcl_au=1.1.811638796.1701393935',
    'Connection': 'keep-alive',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.2;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:PJRL3BQR0W8N4MKOI8LU;msgID:I2023112218005302BNxSJv8Its;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1700647253730450889;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
    'Referer': 'https://www.momoshop.com.tw/',
    'Content-Length': '78',
    'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
    'x-requested-with': 'XMLHttpRequest',
}

# data_from_api2="""{
#     "edm_npn" : null,
#     "enCustNo" : "3202930231507623",
#     "dt_promo_no" : "D94111200001",
#     "m_promo_no" : "U94111200001",
#     "edm_lpn" : "O7E1i4XGcA0"}
# """

data_from_api2="""{
    "m_promo_no" : "U94111400002",
    "dt_promo_no" : "D94111400001",
    "gift_code" : ""}
"""

info = json.loads(data_from_api2)
def main():
    r1 = requests.post('https://event.momoshop.com.tw/promoMechReg.PROMO',headers=headers1,json=info)
    print(r1.text)
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))


#True=等待時間到/False=直接開始跑
run_now = False
if run_now == False:
    t4 = datetime.datetime.now()
else:
    today = datetime.datetime.now().strftime("%d")
    months = datetime.datetime.now().strftime("%m")
    years = datetime.datetime.now().strftime("%Y")
    t4 = datetime.datetime(int(years),int(months),int(today),9,59,59,700000)     #搶折扣的時間     *****檢查*****
    print(t4)

while datetime.datetime.now() < t4:
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
    time.sleep(0.1)
    continue
while datetime.datetime.now() >= t4 and datetime.datetime.now() < t4 + datetime.timedelta(seconds=3):
    threads = []
    times = 1
    for i in range(times):
        threads.append(threading.Thread(target = main))
        threads[i].start()
    time.sleep(0.1)
while datetime.datetime.now() > t4 + datetime.timedelta(seconds=10):
    time.sleep(9999)
