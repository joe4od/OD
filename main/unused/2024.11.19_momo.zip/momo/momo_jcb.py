import os
import requests
import time
import json
import datetime
import threading

# cookies
cookies = [
    '_edcid=MjAxNjA4NDkxOTI0; _eds=1701393081; _edvid=571154f0-8faa-11ee-974d-bbfc4160fefa; _ga_BKEC67VMMG=GS1.1.1701393935.1.1.1701394174.10.0.0; _atrk_sessidx=17; _atrk_siteuid=fqWX6qk-cp4lHzAY; _atrk_ssid=jmFLvhHcvhdXPlwk9624_U; _atrk_xuid=dfdbfd4bad38bf0483d42526dd386a29613ca4c225529b496311c079099519b2; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=7; appier_pv_counterc7279b5af7b77d1=6; appier_utmz=%7B%7D; loginRsult=1; arkLogin=; cto_bundle=R_elml9ZN05iQWhNcE1kWWF0NEEyblFCaVJ2RjVSNkRIZkRaRGdIYzhKREtTMzJ4TURBJTJGJTJCNmFUUU5JQXZsakFaQXlJVFE5cWJJcWtydExWTDcyaXZRTTF0cDlCZFBoMVlQd1I4S1A3Q0N1cjZIbDkzUEFsUGxDeWNCVkNiUDF4YUllZU0; JSESSIONID=2EDB39B012AE96007A0E27F06CC98900; ck_encust=3202930231507623; isEN=5303cbb9a7beeb85e4d554acf7ee7c2724b1aa2b; bid=0e7319daf4395874401c6d36bac66b70; isBI=1; isTN1=1; st=a9d90c2789a5601e03e3d9c0e7bb0785; CM=undefined; CN=undefined; TN=undefined; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _fbp=fb.3.1701393935268.1383758280; _ga=GA1.1.305863393.1701393935; _gcl_au=1.1.811638796.1701393935',
    'JSESSIONID=8CB1EDE157E042FF3984A7F9504F9D60; cto_bundle=qhwpj19VcU02dm5UbVpJWDMycmNIVzBDN1RwcW5hWVdoYmdUbnVoaTVqdTMlMkJKWVFWRkx1cXVTNGJjcGpvcWIlMkYlMkZENTV3MiUyQjBmOVZXUW0wbTNSWEVKdVklMkJ2RkRRcDFDY2N2dVFsZTIlMkIzJTJCS0owdkhqRmZIRlplVnVSM3p2ZE1ibW1PVTRi; _atrk_sessidx=11; _atrk_siteuid=ycXQbwKreCh5IEYW; _atrk_ssid=Tv1j6GcmlKdW2F8d7nH68d; _atrk_xuid=65c662f4e335bb8ebec439e60bcbcc92de88f1f2e085f5f351aa51f29e843ec3; _edcid=MjAxNDAxNjY2NzYx; _eds=1700653253; _edvid=fdd04d30-892b-11ee-9530-0d920111747c; _ga_BKEC67VMMG=GS1.1.1700653281.1.1.1700654122.24.0.0; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=4; appier_pv_counterc7279b5af7b77d1=3; appier_utmz=%7B%7D; loginRsult=1; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; bid=40c231c98ce97ff60e22350d6828a758; isBI=1; CM=undefined; CN=undefined; TN=undefined; ck_encust=3201140126667761; isEN=56d213b0a60791ab58cac6989e75806758512f06; _fbp=fb.3.1700653281150.1374435174; _ga=GA1.1.273222894.1700653281; _gcl_au=1.1.1515190177.1700653281; arkLogin=0; _wau=201401666761.35.1',
    '_atrk_sessidx=6; _atrk_siteuid=9Su2Y-mj5NhjAGN3; _atrk_ssid=yttnCsTigwRnPAH-S8U7JS; _atrk_xuid=8a9b70e5fcc9c61f50244e2533fe53d7cab7689f13c908a1ef822c793bd2b12a; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=7; appier_pv_counterc7279b5af7b77d1=4; appier_utmz=%7B%22csr%22%3A%22www.momoshop.com.tw%22%2C%22timestamp%22%3A1701367314%2C%22lcsr%22%3A%22www.momoshop.com.tw%22%7D; loginRsult=1; arkLogin=; cto_bundle=oV7bxl8yVFA5NmRvUXhwTGNEdWEyeSUyRmJGV1ZoZWxocGw3NTVBMEhCMyUyRlBaJTJGc2VyNjl5RmVOSkRHMEllM08wRUhFSEJ5JTJCb1E4Y1hnQUR1WGp3bGZxYkptbE9oSnZoQyUyRlc2JTJGRWZkVXZFWTlOUyUyRk9sRnklMkJOOGdyb2djN0VqTEc3MDJaYUQwRm56UzVtQ2M5TW1lSCUyRjRnSWVFRFBENnMxU3FBVWxGaDF6SmJkN2g3MWMlM0Q; ck_encust=3201360844916924; isEN=4b3050b55c09407d94b0df3d7a176a9ce401f432; JSESSIONID=03DD2655A89DD42B8E97C42884C5DAA5; _edcid=MjAxNjA4NDkxOTI0; _eds=1701393081; _edvid=571154f0-8faa-11ee-974d-bbfc4160fefa; _ga_BKEC67VMMG=GS1.1.1701393081.4.0.1701393081.60.0.0; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; isBI=1; isTN1=1; st=bd4500059177f6fb4755436cb0c69e6e; bid=84d817159778a1d5ca830bc29033a84e; _ga=GA1.1.1228977839.1701367354; _gcl_au=1.1.1651992683.1701367354',
]

employeeIDs = [
    '3202930231507623',
    '3201240186661761',
    '3201360844916924',
]

# 主程式
def main():
    for i in range(len(employeeIDs)):
            headers1= {
                'Host': 'event.momoshop.com.tw',
                'Content-type': 'application/json;charset=utf-8',
                'Origin': 'https://www.momoshop.com.tw',
                'Accept-Encoding': 'gzip, deflate, br',
                'Cookie': """""" + cookies[i] + """""",
                'Connection': 'keep-alive',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.6;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:2PIXHZK84I1P840N723K;msgID:I2023121308404155OWdNhUt5kn;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1702428042907010156;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
                'Referer': 'https://www.momoshop.com.tw/',
                'Content-Length': '78',
                'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
                'x-requested-with': 'XMLHttpRequest',
            }

            log="""{
                "m_promo_no" : "M24010100018",
                "dt_promo_no" : "D24010100001",
                "gift_code" : "JCB700"
            }"""
            log_r = requests.post('https://event.momoshop.com.tw/promoMechReg.PROMO',headers=headers1,json=json.loads(log))
            print(log_r.text)
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))

# 執行主程式
main()