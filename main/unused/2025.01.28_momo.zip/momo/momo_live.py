import os
import requests
import time
import json
import datetime
import threading

# cookies
cookies = [
    'cto_bundle=-qd3A19ZN05iQWhNcE1kWWF0NEEyblFCaVJzcTJrR0c5UWgwREhORFhuQlIlMkZjSE9sWG15JTJGUTNJZkxDQkhZT2owRHBsczc1N1UlMkJ3WDJtSTN5RGxxVWZhaERiUXNUWFNUR3RtT0FxSUp4SUxsVDdhN2R0bTlLMFhmbUVwM3JtcHdsSXBWWQ; bid=29da0313274622c791b7a5a7ff8db290; isBI=1; loginRsult=1; JSESSIONID=9AFC8B86E43C7733EC3C4FD0B6944CC4; CM=undefined; CN=undefined; TN=undefined; _atrk_sessidx=7; _atrk_siteuid=fqWX6qk-cp4lHzAY; _atrk_ssid=jmFLvhHcvhdXPlwk9624_U; _atrk_xuid=13e578cbab23647579a187331f7213e0b468b20f9c2fdd1746e04f83c6c5c8f0; appier_page_isView_ERlDyPL9yO7gfOb=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_page_isView_c7279b5af7b77d1=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_pv_counterERlDyPL9yO7gfOb=2; appier_pv_counterc7279b5af7b77d1=1; appier_utmz=%7B%7D; ck_encust=3202831186995295; isEN=b10da144f777d755770cf574baa453fb96b66e5a; _edcid=MjAxNjA4NDkxOTI0; _eds=1701393081; _edvid=571154f0-8faa-11ee-974d-bbfc4160fefa; _ga_BKEC67VMMG=GS1.1.1701393935.1.1.1701393941.54.0.0; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _fbp=fb.3.1701393935268.1383758280; _ga=GA1.1.305863393.1701393935; _gcl_au=1.1.811638796.1701393935; arkLogin=0',
    '_edcid=MjAxNjA4NDkxOTI0; _eds=1701393081; _edvid=571154f0-8faa-11ee-974d-bbfc4160fefa; _ga_BKEC67VMMG=GS1.1.1701393935.1.1.1701394174.10.0.0; _atrk_sessidx=17; _atrk_siteuid=fqWX6qk-cp4lHzAY; _atrk_ssid=jmFLvhHcvhdXPlwk9624_U; _atrk_xuid=dfdbfd4bad38bf0483d42526dd386a29613ca4c225529b496311c079099519b2; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=7; appier_pv_counterc7279b5af7b77d1=6; appier_utmz=%7B%7D; loginRsult=1; arkLogin=; cto_bundle=R_elml9ZN05iQWhNcE1kWWF0NEEyblFCaVJ2RjVSNkRIZkRaRGdIYzhKREtTMzJ4TURBJTJGJTJCNmFUUU5JQXZsakFaQXlJVFE5cWJJcWtydExWTDcyaXZRTTF0cDlCZFBoMVlQd1I4S1A3Q0N1cjZIbDkzUEFsUGxDeWNCVkNiUDF4YUllZU0; JSESSIONID=2EDB39B012AE96007A0E27F06CC98900; ck_encust=3202930231507623; isEN=5303cbb9a7beeb85e4d554acf7ee7c2724b1aa2b; bid=0e7319daf4395874401c6d36bac66b70; isBI=1; isTN1=1; st=a9d90c2789a5601e03e3d9c0e7bb0785; CM=undefined; CN=undefined; TN=undefined; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _fbp=fb.3.1701393935268.1383758280; _ga=GA1.1.305863393.1701393935; _gcl_au=1.1.811638796.1701393935',
    'JSESSIONID=8CB1EDE157E042FF3984A7F9504F9D60; cto_bundle=qhwpj19VcU02dm5UbVpJWDMycmNIVzBDN1RwcW5hWVdoYmdUbnVoaTVqdTMlMkJKWVFWRkx1cXVTNGJjcGpvcWIlMkYlMkZENTV3MiUyQjBmOVZXUW0wbTNSWEVKdVklMkJ2RkRRcDFDY2N2dVFsZTIlMkIzJTJCS0owdkhqRmZIRlplVnVSM3p2ZE1ibW1PVTRi; _atrk_sessidx=11; _atrk_siteuid=ycXQbwKreCh5IEYW; _atrk_ssid=Tv1j6GcmlKdW2F8d7nH68d; _atrk_xuid=65c662f4e335bb8ebec439e60bcbcc92de88f1f2e085f5f351aa51f29e843ec3; _edcid=MjAxNDAxNjY2NzYx; _eds=1700653253; _edvid=fdd04d30-892b-11ee-9530-0d920111747c; _ga_BKEC67VMMG=GS1.1.1700653281.1.1.1700654122.24.0.0; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=4; appier_pv_counterc7279b5af7b77d1=3; appier_utmz=%7B%7D; loginRsult=1; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; bid=40c231c98ce97ff60e22350d6828a758; isBI=1; CM=undefined; CN=undefined; TN=undefined; ck_encust=3201140126667761; isEN=56d213b0a60791ab58cac6989e75806758512f06; _fbp=fb.3.1700653281150.1374435174; _ga=GA1.1.273222894.1700653281; _gcl_au=1.1.1515190177.1700653281; arkLogin=0; _wau=201401666761.35.1',
    'cto_bundle=Sbecil82RURVOEZzUko4SmZ2Q0ZMVG80Nlh5b080V1JDM09CbCUyRmtGc1hWWml3byUyQiUyQkluTWxGbUs3SExiblNyZTBYaERNalRITXd4am4lMkZrSmxGV3BSem1QYVZvU2JXbk1JdmtRbXdiUk9hMzQyOHJDRFltYnIxWG5NQzg4cTJIWHRhdld5; bid=8e2624f128350bbfd54a12d06bd5475a; isBI=1; loginRsult=1; JSESSIONID=C92431BDD70DCAEE7E40F51F59D19CDE; _atrk_sessidx=7; _atrk_siteuid=94bnUHPh65UNIu2P; _atrk_ssid=BJKF7twcEXZOTx7-QwmvNu; _atrk_xuid=c03b836ae4fa740d99f974c6296cc5caf1b2e2e34aaa6a1c8d177ae36417ce5f; appier_page_isView_ERlDyPL9yO7gfOb=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_page_isView_c7279b5af7b77d1=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_pv_counterERlDyPL9yO7gfOb=2; appier_pv_counterc7279b5af7b77d1=1; appier_utmz=%7B%7D; CM=undefined; CN=undefined; TN=undefined; ck_encust=3202631053924327; isEN=c2949ec8f6ff690c5ac61661133bb22b2bcc3e99; _edcid=MjAxNjA4NDkxOTI0; _eds=1701393081; _edvid=571154f0-8faa-11ee-974d-bbfc4160fefa; _ga_BKEC67VMMG=GS1.1.1701394246.1.1.1701394253.53.0.0; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _ga=GA1.1.2120360281.1701394246; _gcl_au=1.1.284921287.1701394246; _fbp=fb.3.1701394245839.1224987469; arkLogin=0',
    'cto_bundle=r4P90F9IcW9BUkZibTh2aGtSY3ZUandHd2VjTVRjN2ZVYkZVeXUzSTB0SEdYdVdDVU4lMkZ0VnZabXdseVFIYTdmVVZRbXltdExUTlpYQVljSU9pSVd0VFRjbXJDUkJoZ0g5UjYwT1VGUVMwcUt4dDBaUFRlQloxRGt4OXVNZFZKUWZLbThk; bid=1cfc18dfe22da0752208d7ba8e981ec3; isBI=1; loginRsult=1; _atrk_sessidx=7; _atrk_siteuid=xLY0s-uVAs3a_S4C; _atrk_ssid=LHF3Gvc24-mesTM46Z436v; _atrk_xuid=b73e6788658f779acd293f710445cdd0b64fb5e7611ead4ac0607f547f3678a7; appier_page_isView_ERlDyPL9yO7gfOb=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_page_isView_c7279b5af7b77d1=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_pv_counterERlDyPL9yO7gfOb=2; appier_pv_counterc7279b5af7b77d1=1; appier_utmz=%7B%7D; JSESSIONID=8D37C90ACBCA9D03F88370C83D2C654D; CM=undefined; CN=undefined; TN=undefined; ck_encust=3202630211563922; isEN=1b646af4309db4422a03a7d30b9949fe25f5a9cb; _eds=1701394319; _edvid=6b700740-8fe9-11ee-8531-d1021fd4c398; _ga_BKEC67VMMG=GS1.1.1701394318.1.1.1701394340.38.0.0; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _fbp=fb.3.1701394331540.2006302378; arkLogin=0; _ga=GA1.1.614730245.1701394319; _gcl_au=1.1.1158076230.1701394319',
    '_atrk_sessidx=6; _atrk_siteuid=9Su2Y-mj5NhjAGN3; _atrk_ssid=yttnCsTigwRnPAH-S8U7JS; _atrk_xuid=8a9b70e5fcc9c61f50244e2533fe53d7cab7689f13c908a1ef822c793bd2b12a; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=7; appier_pv_counterc7279b5af7b77d1=4; appier_utmz=%7B%22csr%22%3A%22www.momoshop.com.tw%22%2C%22timestamp%22%3A1701367314%2C%22lcsr%22%3A%22www.momoshop.com.tw%22%7D; loginRsult=1; arkLogin=; cto_bundle=oV7bxl8yVFA5NmRvUXhwTGNEdWEyeSUyRmJGV1ZoZWxocGw3NTVBMEhCMyUyRlBaJTJGc2VyNjl5RmVOSkRHMEllM08wRUhFSEJ5JTJCb1E4Y1hnQUR1WGp3bGZxYkptbE9oSnZoQyUyRlc2JTJGRWZkVXZFWTlOUyUyRk9sRnklMkJOOGdyb2djN0VqTEc3MDJaYUQwRm56UzVtQ2M5TW1lSCUyRjRnSWVFRFBENnMxU3FBVWxGaDF6SmJkN2g3MWMlM0Q; ck_encust=3201360844916924; isEN=4b3050b55c09407d94b0df3d7a176a9ce401f432; JSESSIONID=03DD2655A89DD42B8E97C42884C5DAA5; _edcid=MjAxNjA4NDkxOTI0; _eds=1701393081; _edvid=571154f0-8faa-11ee-974d-bbfc4160fefa; _ga_BKEC67VMMG=GS1.1.1701393081.4.0.1701393081.60.0.0; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; isBI=1; isTN1=1; st=bd4500059177f6fb4755436cb0c69e6e; bid=84d817159778a1d5ca830bc29033a84e; _ga=GA1.1.1228977839.1701367354; _gcl_au=1.1.1651992683.1701367354',
    'cto_bundle=GZVoC19aTjBJUzRHZXhUZDBQSlFZeERqZHlMQUd4UGlob2NGeFByWlUxTE53NWluQ1Y3a0dKUHRmVFd0QW1oSUx4WVNZMlBOMkZmTTNwbklkdmFzVWt0VCUyRlJ5U1pVbnlmZjRudSUyRmtCRGkzdSUyQjNYTTM4bTI1a0I4bzBoM0RVaXRxTTdzcGdXT1ptNktmMkFyaXc2Z2Y2WlptNE5OSGdLJTJCYXVKUG1nUnQ4dWlJTSUyRkQ4JTNE; JSESSIONID=29DCD250AD4116623D70B773482264E1; _atrk_sessidx=11; _atrk_siteuid=bMyuQOJoePtRpwJq; _atrk_ssid=sAe7voCi2YlyFa90qPbS44; _atrk_xuid=d11327c4abaf4d62b85469012722914cd599ba7632e675f0d5e7f040ad12060c; appier_page_isView_ERlDyPL9yO7gfOb=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_page_isView_c7279b5af7b77d1=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_pv_counterERlDyPL9yO7gfOb=4; appier_pv_counterc7279b5af7b77d1=4; appier_utmz=%7B%7D; loginRsult=1; _eds=1701666802; _edvid=ce3befd0-9244-11ee-bae9-9f9eef6db8c3; _ga_BKEC67VMMG=GS1.1.1701666802.3.1.1701666978.60.0.0; ck_encust=3201500581413603; isEN=f83bdd5491a2b85cf27bf21a155aee42c66f858a; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; arkLogin=0; bid=6f3dd720999154b075a2cb0a10fd08c3; isBI=1; isTN1=1; st=6ba6d954a27c050f3d688ad0ec5fc262; _ga=GA1.1.1577905220.1701653976; _gcl_au=1.1.541180091.1701653976',
    # kenny
    'ck_encust=3201020579750183; isEN=7af1582bcbcb121ae2bb1f841eb5a1a68e880b18;',
    'ck_encust=3201590254632763; isEN=e3f9cc735f327397ab5ef363e7344b2fe6295f97;',
    'ck_encust=3202230241066625; isEN=d8f84148f518857cd519087aa9be3b55558449fd;',
    'ck_encust=3201580401658449; isEN=663b5112cf6af386399603dfe3bb2775fe56152a;',
]

employeeIDs = [
    '3202831186995295',
    '3202930231507623',
    '3201240186661761',
    '3202631053924327',
    '3202630211563922',
    '3201360844916924',
    '3201100521416603',
    # kenny
    '3201020579750183',
    '3201590254632763',
    '3202230241066625',
    '3201580401658449',
]

# 主程式
def main():
    for i in range(len(employeeIDs)):
            headers1= {
                'Host': 'event.momoshop.com.tw',
                'Content-type': 'application/json;charset=utf-8',
                'Origin': 'https://www.momoshop.com.tw',
                'Accept-Encoding': 'gzip, deflate, br',
                'Cookie': """""" + cookies[i] + """""",
                'Connection': 'keep-alive',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.6;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:2PIXHZK84I1P840N723K;msgID:I2023121308404155OWdNhUt5kn;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1702428042907010156;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
                'Referer': 'https://www.momoshop.com.tw/',
                'Content-Length': '78',
                'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
                'x-requested-with': 'XMLHttpRequest',
            }

            qry="""{
              "qry_type" : "1002",
              "enCustNo": """ + employeeIDs[i] + """,
              "m_promo_no": "M24012200024",
              "dt_promo_no": "D24012200001"
            }"""
            qry_r = requests.post('https://event.momoshop.com.tw/promoMechQry.PROMO',headers=headers1,json=json.loads(qry))
            print(qry_r.text)
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))

            ins="""{
              "cnt_type" : "1006",
              "m_promo_no": "M24012200024",
              "dt_promo_no": "D24012200001"
            }"""
            ins_r = requests.post('https://event.momoshop.com.tw/promoMechCnt.PROMO',headers=headers1,json=json.loads(ins))
            print(ins_r.text)
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))

            log="""{
              "gift_code" : "Gift001",
              "enCustNo": """ + employeeIDs[i] + """,
              "m_promo_no": "M24012200024",
              "dt_promo_no": "D24012200001",
              "cysec": "HFs2u7qzaY729mTMBrQQRGxQEqamS0S62VXUjI2UMmk="
#               "cysec": "1OIvkkOJTIXT66S5xz2aEqk9DXXzrEzKmfMm6b3hv4o="
            }"""
            log_r = requests.post('https://event.momoshop.com.tw/promoMechReg.PROMO',headers=headers1,json=json.loads(log))
            print(log_r.text)
            print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))

# 執行主程式
main()