import os
import requests
import time
import json
import datetime
import threading
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError as e:
        return False
    return True
headers1= {
    'Host': 'event.momoshop.com.tw',
    'Content-type': 'application/json;charset=utf-8',
    'Origin': 'https://www.momoshop.com.tw',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cookie': 'cto_bundle=xJ7lfl94b1RKMUZkaTdpVTRKSkhlSiUyRndFNUVUc1NUN3NRZjhIODRSYiUyRmJLTkVlJTJCd0p1b0xmTnIzTlRtbzIwYmVjcTE0cW5IZFI0U3l3R1klMkZ5ZU1kUnYlMkJTTE5HSnhJUUlNeEhKTVBrQm5lQlBPRTMyV0xvSEJlSE9zUCUyQjR0Vk1oMTBGcXdRTmJ0azlrNFozN1BZYjZjbDFtQlhZMnZxT24xUGVRWnNFcWFOemNGMUklM0Q; arkLogin=; loginRsult=1; loginUser=*%E6%B2%BB*%20; _atrk_sessidx=13; _atrk_siteuid=2XH9jnSMkwN2ldwX; _atrk_ssid=C-y44Rai3PZCFipfxh97YB; _atrk_xuid=65c662f4e335bb8ebec439e60bcbcc92de88f1f2e085f5f351aa51f29e843ec3; _eds=1737735789; _edvid=7f8c9780-da6f-11ef-818f-8d5ca24ae9d1; _ga_BKEC67VMMG=GS1.1.1737735788.1.1.1737737154.25.0.0; appier_page_isView_ERlDyPL9yO7gfOb=f8202808e15240641d948e79ffa52fb0b0ee03776d46ec404611a32c401980d4; appier_page_isView_c7279b5af7b77d1=f8202808e15240641d948e79ffa52fb0b0ee03776d46ec404611a32c401980d4; appier_pv_counterERlDyPL9yO7gfOb=5; appier_pv_counterc7279b5af7b77d1=3; appier_utmz=%7B%7D; WishListNumber=0; _wau=201401666761.37.1; ccmedia=201401666761_/1_/37; ck_encust=3201940166660761; ck_mlu="RjEyNzM0MTE4Ng=="; couponNumber=66; isEN=a16862da7aa62b00ab5b06e7b893369c3baa5f7a; isBI=1; isTN1=1; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; st=f1c08fccbf884c3adbc6a6f969e8acc8; _tt_enable_cookie=1; _ttp=JL42Y-jZXak_aLHl7eeupmKvEZ4.tt.2; _fbp=fb.3.1737735802370.1892664701; bid=165122b8d41c5fb00fb4d5f71d0bf2db; _ga=GA1.1.1505959790.1737735789; _gcl_au=1.1.1577470220.1737735789; CM=undefined; CN=undefined; TN=undefined',
    'Connection': 'keep-alive',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.2;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:PJRL3BQR0W8N4MKOI8LU;msgID:I2023112218005302BNxSJv8Its;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1700647253730450889;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
    'Referer': 'https://www.momoshop.com.tw/',
    'Content-Length': '78',
    'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
    'x-requested-with': 'XMLHttpRequest',
}

data_from_api2="""{
    "action" : "lottery"}
"""

info = json.loads(data_from_api2)
def main():
    r1 = requests.post('https://event.momoshop.com.tw/customizedpromo/chargeLottery.PROMO',headers=headers1,json=info)
    print(r1.text)
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))


#True=等待時間到/False=直接開始跑
run_now = True
if run_now == False:
    t4 = datetime.datetime.now()
else:
    today = datetime.datetime.now().strftime("%d")
    months = datetime.datetime.now().strftime("%m")
    years = datetime.datetime.now().strftime("%Y")
    t4 = datetime.datetime(2025,1,26,0,0,0,700000)     #搶折扣的時間     *****檢查*****
    print(t4)

while datetime.datetime.now() < t4:
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
    time.sleep(0.1)
    continue
while datetime.datetime.now() >= t4 and datetime.datetime.now() < t4 + datetime.timedelta(seconds=5):
    threads = []
    times = 1
    for i in range(times):
        threads.append(threading.Thread(target = main))
        threads[i].start()
    time.sleep(0.5)
while datetime.datetime.now() > t4 + datetime.timedelta(seconds=10):
    time.sleep(9999)
