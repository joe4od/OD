import os
import requests
import time
import json
import datetime
import threading
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError as e:
        return False
    return True
headers1= {
    'Host': 'event.momoshop.com.tw',
    'Content-type': 'application/json;charset=utf-8',
    'Origin': 'https://www.momoshop.com.tw',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cookie': 'cto_bundle=SF2KGl82M0xic1pIWHFRZndlM29PR3IlMkI5UlJOT3RXUGhQNE8lMkJDMnZuRjQ4djlBdkczNldPc3lxejMwR2p2WU5Na0k3cTIlMkI0b0tJeWNweGRMdERaRzN0N0dRYUloN2FlaiUyQnpUUGxXZ2NRMzZwUSUyRjNYQVdkZlVPVmxkSXR4d3pMRXlETVdKRk9JZFdXMEMzWGNSclF6JTJCdkZ6ZmpteFU0d2NNdzRKeExCQUxxeklReU0lM0Q; _edcid=MjAxNjA4NDkxOTI0; _eds=1737734715; _edvid=193d7ae0-d9f1-11ef-9db2-d140858065bd; _ga_BKEC67VMMG=GS1.1.1737734257.6.1.1737734752.22.0.0; _atrk_sessidx=15; _atrk_siteuid=Akjb_oUq-Fku6L5z; _atrk_ssid=o4w9dx9g0ZNw9AoGMaoPH6; _atrk_xuid=8a9b70e5fcc9c61f50244e2533fe53d7cab7689f13c908a1ef822c793bd2b12a; appier_page_isView_ERlDyPL9yO7gfOb=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_page_isView_c7279b5af7b77d1=ff4115d42c15801bc94f2b8913a82a0bef9bd1b64c65ce818d5e18234af67330; appier_pv_counterERlDyPL9yO7gfOb=6; appier_pv_counterc7279b5af7b77d1=5; appier_utmz=%7B%7D; arkLogin=0; bid=20c28db5e7d69b85a90964d04a9457bc; ccmedia=201608491924_/0_/00; ck_encust=3201860884911924; isBI=1; isEN=b937dbe0c86ac83d9fc57df67c6f0fc3b05c5c8f; isTN1=1; loginRsult=1; loginUser=*%E6%99%8F*%20; st=ba55eaf24b5cd1fd9cb3aa393de030ca; WishListNumber=1; _wau=201608491924.37.2; ck_mlu="UjIyMzY0OTE4Mg=="; couponNumber=71; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _tt_enable_cookie=1; _ttp=3W5_JGj44QCL4XkIGElcFuS_FF4.tt.2; _ga=GA1.1.2006203890.1737681500; _gcl_au=1.1.897429024.1737681500',
    'Connection': 'keep-alive',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.2;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:PJRL3BQR0W8N4MKOI8LU;msgID:I2023112218005302BNxSJv8Its;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1700647253730450889;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
    'Referer': 'https://www.momoshop.com.tw/',
    'Content-Length': '78',
    'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
    'x-requested-with': 'XMLHttpRequest',
}

data_from_api2="""{
    "action" : "lottery"}
"""

info = json.loads(data_from_api2)
def main():
    r1 = requests.post('https://event.momoshop.com.tw/customizedpromo/chargeLottery.PROMO',headers=headers1,json=info)
    print(r1.text)
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))


#True=等待時間到/False=直接開始跑
run_now = True
if run_now == False:
    t4 = datetime.datetime.now()
else:
    today = datetime.datetime.now().strftime("%d")
    months = datetime.datetime.now().strftime("%m")
    years = datetime.datetime.now().strftime("%Y")
    t4 = datetime.datetime(2025,1,26,0,0,0,700000)     #搶折扣的時間     *****檢查*****
    print(t4)

while datetime.datetime.now() < t4:
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
    time.sleep(0.1)
    continue
while datetime.datetime.now() >= t4 and datetime.datetime.now() < t4 + datetime.timedelta(seconds=5):
    threads = []
    times = 1
    for i in range(times):
        threads.append(threading.Thread(target = main))
        threads[i].start()
    time.sleep(0.5)
while datetime.datetime.now() > t4 + datetime.timedelta(seconds=10):
    time.sleep(9999)
