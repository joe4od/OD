import os
import requests
import time
import json
import datetime
import threading
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError as e:
        return False
    return 2025,1,26
headers1= {
    'Host': 'event.momoshop.com.tw',
    'Content-type': 'application/json;charset=utf-8',
    'Origin': 'https://www.momoshop.com.tw',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cookie': 'cto_bundle=xq6yzV9SNHByZ0g4ZUJDMmJtUXclMkJYMVpOTkxaeGJNYTlYRWg3c2Z1UjZRS0RQa0tFUVBnb09qb1VkOVYlMkI1RyUyRmFiU3hkWk9CUzNhNGdobGxLRGdveE1HT1BncDltOEd6YyUyRnZweGY0Qkg2S1JhOHE3bU9jNE80NDVoMWQwdnR6TVZXdzF3WWJUNlFYa0U5QzVjQVdWZlJmckswUHZzNDVUT2NvbUVnQWxyMzRZOTFIayUzRA; loginRsult=1; loginUser=*%E8%BF%AA*%20; _atrk_sessidx=9; _atrk_siteuid=4cX360LnFxmyYTWr; _atrk_ssid=UE3JxRkqAuSqglALNfAFX3; _atrk_xuid=13e578cbab23647579a187331f7213e0b468b20f9c2fdd1746e04f83c6c5c8f0; appier_page_isView_ERlDyPL9yO7gfOb=f8202808e15240641d948e79ffa52fb0b0ee03776d46ec404611a32c401980d4; appier_page_isView_c7279b5af7b77d1=f8202808e15240641d948e79ffa52fb0b0ee03776d46ec404611a32c401980d4; appier_pv_counterERlDyPL9yO7gfOb=3; appier_pv_counterc7279b5af7b77d1=3; appier_utmz=%7B%7D; _eds=1737737210; _edvid=ce978c60-da72-11ef-93bf-517d9f2237f3; _ga_BKEC67VMMG=GS1.1.1737737209.1.1.1737737250.19.0.0; WishListNumber=0; _wau=202311699295.37.1; ccmedia=202311699295_/1_/37; ck_encust=3202431156994295; ck_mlu="RjEzNjAzMzcxMw=="; couponNumber=74; isEN=5a94344cbd5daa3c248effeb69b2fb140df72cab; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; _fbp=fb.3.1737737223145.2008119327; arkLogin=0; isBI=1; isTN1=1; st=441bb04db2494bb0b50ceaf24511f3c3; _tt_enable_cookie=1; _ttp=yVpa0aZpyd4P5QA51EMitwaeSV-.tt.2; _ga=GA1.1.888001515.1737737210; _gcl_au=1.1.478139716.1737737210; CM=undefined; CN=undefined; TN=undefined',
    'Connection': 'keep-alive',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.2;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:PJRL3BQR0W8N4MKOI8LU;msgID:I2023112218005302BNxSJv8Its;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1700647253730450889;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
    'Referer': 'https://www.momoshop.com.tw/',
    'Content-Length': '78',
    'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
    'x-requested-with': 'XMLHttpRequest',
}

data_from_api2="""{
    "action" : "lottery"}
"""

info = json.loads(data_from_api2)
def main():
    r1 = requests.post('https://event.momoshop.com.tw/customizedpromo/chargeLottery.PROMO',headers=headers1,json=info)
    print(r1.text)
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))


#2025,1,26=等待時間到/False=直接開始跑
run_now = 2025,1,26
if run_now == False:
    t4 = datetime.datetime.now()
else:
    today = datetime.datetime.now().strftime("%d")
    months = datetime.datetime.now().strftime("%m")
    years = datetime.datetime.now().strftime("%Y")
    t4 = datetime.datetime(2025,1,26,0,0,0,700000)     #搶折扣的時間     *****檢查*****
    print(t4)

while datetime.datetime.now() < t4:
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
    time.sleep(0.1)
    continue
while datetime.datetime.now() >= t4 and datetime.datetime.now() < t4 + datetime.timedelta(seconds=5):
    threads = []
    times = 1
    for i in range(times):
        threads.append(threading.Thread(target = main))
        threads[i].start()
    time.sleep(0.5)
while datetime.datetime.now() > t4 + datetime.timedelta(seconds=10):
    time.sleep(9999)
