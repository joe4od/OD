import os
import requests
import time
import json
import datetime
import threading
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError as e:
        return False
    return True
headers1= {
    'Host': 'event.momoshop.com.tw',
    'Content-type': 'application/json;charset=utf-8',
    'Origin': 'https://www.momoshop.com.tw',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cookie': 'cto_bundle=GZVoC19aTjBJUzRHZXhUZDBQSlFZeERqZHlMQUd4UGlob2NGeFByWlUxTE53NWluQ1Y3a0dKUHRmVFd0QW1oSUx4WVNZMlBOMkZmTTNwbklkdmFzVWt0VCUyRlJ5U1pVbnlmZjRudSUyRmtCRGkzdSUyQjNYTTM4bTI1a0I4bzBoM0RVaXRxTTdzcGdXT1ptNktmMkFyaXc2Z2Y2WlptNE5OSGdLJTJCYXVKUG1nUnQ4dWlJTSUyRkQ4JTNE; JSESSIONID=29DCD250AD4116623D70B773482264E1; _atrk_sessidx=11; _atrk_siteuid=bMyuQOJoePtRpwJq; _atrk_ssid=sAe7voCi2YlyFa90qPbS44; _atrk_xuid=d11327c4abaf4d62b85469012722914cd599ba7632e675f0d5e7f040ad12060c; appier_page_isView_ERlDyPL9yO7gfOb=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_page_isView_c7279b5af7b77d1=91c9a24ef540c6612518c5602270a25d793350d6d2241d12b6740eb4d70d190d; appier_pv_counterERlDyPL9yO7gfOb=4; appier_pv_counterc7279b5af7b77d1=4; appier_utmz=%7B%7D; loginRsult=1; _eds=1701666802; _edvid=ce3befd0-9244-11ee-bae9-9f9eef6db8c3; _ga_BKEC67VMMG=GS1.1.1701666802.3.1.1701666978.60.0.0; ck_encust=3201500581413603; isEN=f83bdd5491a2b85cf27bf21a155aee42c66f858a; mg=57b7c2f920dd4d4cb2ac0164d8e82305609f234e; arkLogin=0; bid=6f3dd720999154b075a2cb0a10fd08c3; isBI=1; isTN1=1; st=6ba6d954a27c050f3d688ad0ec5fc262; _ga=GA1.1.1577905220.1701653976; _gcl_au=1.1.541180091.1701653976',
    'Connection': 'keep-alive',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148[MOMOSHOP version:5.42.2;monet:;device:iOS;deviceID:57b7c2f920dd4d4cb2ac0164d8e82305609f234e;deviceName:iPhone X;platform:1;userToken:PJRL3BQR0W8N4MKOI8LU;msgID:I2023112218005302BNxSJv8Its;twm:0;canUseSignInWithApple:YES;canUseApplePay:YES;canUseLinePay:YES;CANUSEJKOPAY:YES;canUseEasyWallet:YES;mowaSessionId:1700647253730450889;canTrackingAuthorized:YES;systemNotificationStatus:0;MOMOSHOP] showTB=0',
    'Referer': 'https://www.momoshop.com.tw/',
    'Content-Length': '78',
    'Accept-Language': 'zh-TW,zh-Hant;q=0.9',
    'x-requested-with': 'XMLHttpRequest',
}

data_from_api2="""{
    "edm_npn" : null,
    "enCustNo" : "3201100521416603",
    "dt_promo_no" : "D95012300001",
    "m_promo_no" : "U95012300002",
    "edm_lpn" : "O7F1sesffIe"}
"""

# data_from_api2="""{
#     "dt_promo_no" : "D94122300001",
#     "m_promo_no" : "U94122300001",
#     "gift_code" : ""}
# """

info = json.loads(data_from_api2)
def main():
    r1 = requests.post('https://event.momoshop.com.tw/promoMechReg.PROMO',headers=headers1,json=info)
    print(r1.text)
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))


#True=等待時間到/False=直接開始跑
run_now = True
if run_now == False:
    t4 = datetime.datetime.now()
else:
    today = datetime.datetime.now().strftime("%d")
    months = datetime.datetime.now().strftime("%m")
    years = datetime.datetime.now().strftime("%Y")
#     t4 = datetime.datetime(2025,1,28,0,7,59,700000)     #搶折扣的時間     *****檢查*****
#     t4 = datetime.datetime(int(years),int(months),int(today),9,7,59,700000)     #搶折扣的時間     *****檢查*****
#     t4 = datetime.datetime(int(years),int(months),int(today),12,7,59,700000)     #搶折扣的時間     *****檢查*****
    t4 = datetime.datetime(int(years),int(months),int(today),14,7,59,700000)     #搶折扣的時間     *****檢查*****
#     t4 = datetime.datetime(int(years),int(months),int(today),16,7,59,700000)     #搶折扣的時間     *****檢查*****
#     t4 = datetime.datetime(int(years),int(months),int(today),18,7,59,700000)     #搶折扣的時間     *****檢查*****
#     t4 = datetime.datetime(int(years),int(months),int(today),20,7,59,700000)     #搶折扣的時間     *****檢查*****
#     t4 = datetime.datetime(int(years),int(months),int(today),21,7,59,700000)     #搶折扣的時間     *****檢查*****
    print(t4)

while datetime.datetime.now() < t4:
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
    time.sleep(0.1)
    continue
while datetime.datetime.now() >= t4 and datetime.datetime.now() < t4 + datetime.timedelta(seconds=3):
    threads = []
    times = 1
    for i in range(times):
        threads.append(threading.Thread(target = main))
        threads[i].start()
    time.sleep(0.1)
while datetime.datetime.now() > t4 + datetime.timedelta(seconds=10):
    time.sleep(9999)
