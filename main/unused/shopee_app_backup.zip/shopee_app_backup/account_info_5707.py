tax_address  = ""
address_type = 0  #宅配=0
device_id = ""
tongdun_blackbox = ""
device_sz_fingerprint = ""
addressid = ""  #盤商
email = "123@hotmail.com"
channel_id = 3004000 #3008300 銀行轉帳；3004000 信用卡
selected_logistic_channelid = 39304  #賣家宅配=39304 #宅配=39310 #大型宅配=39312 #箱購=39308
warehouse_address_id = 0
shopee_shipping_discount_id = 0
bank_id = 1049
bank_name = "國泰世華銀行"
card_number = ""
expiry_date = ""
channel_item_id = ""
town = ""
city = ""
state = ""
name = ""
district = ""
phone = ""
country = ""
address = ""
zipcode = ""