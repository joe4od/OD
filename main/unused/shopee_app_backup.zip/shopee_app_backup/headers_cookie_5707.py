headers = {
'Host': 'mall.shopee.tw',
'User-Agent': 'iOS app iPhone Shopee appver=29315 language=zh-Hant app_type=1',
'Accept': 'application/json',
'Accept-Language': 'zh-TW,zh,en-US,en,id-ID,id',
'Accept-Encoding': 'gzip, deflate',
'Referer': 'https://mall.shopee.tw/bridge_cmd?cmd=reactPath%3Ftab%3Dbuy%26path%3Dshopee%2FHOME_PAGE%26layout%3D%255Bobject%2520Object%255D%26native_render%3Dsearch_prefills%252Clanding_page_banners%252Chome_squares%252Cskinny_banners%252Cnew_user_zone%252Ccampaign_modules%252Cflash_sales%252Cmall_shops',
'X-CSRFToken': '',
'Content-Type': 'application/json',
'X-Requested-With': 'XMLHttpRequest',
'X-API-SOURCE': 'rn',
'If-None-Match-': '55b03-50648574f8e9f8d54603fe6b92d933a6',
'Origin': 'https://shopee.tw',
'Content-Length': '2491',
'Connection': 'keep-alive',
'Cookie': ''
}