#此次輸入的折扣碼  *****檢查*****
#範例
# voucher_special_00 = [
#      """{"voucher_code":"HFEWU1018",
#         "voucher_promotionid":208082114510848,
#         "signature":"065aa77d543af04fa2ed27b1717789111b7fbcd38366e47242437e80e58bec4e",
#         "signature_source":"3"}"""
# ]

#85商城(40)[1000]
voucher_special_00 = [
"""{
    "voucher_code":"2KBM7HJVHP",
    "voucher_promotionid":602566077808640,
    "signature":"4bc10ce49cf751dc0c8899be2dd2d22bbb32f5111ab35f5ea5563cab00856a2b",
    "signature_source":"3"
   }"""
]

#85實名商城(40)[1000]
voucher_special_12 = [
"""{
    "voucher_code":"2KBM7HJVHP",
    "voucher_promotionid":602566077808640,
    "signature":"4bc10ce49cf751dc0c8899be2dd2d22bbb32f5111ab35f5ea5563cab00856a2b",
    "signature_source":"3"
   }"""
]

#85商城(300)[2000]
# voucher_special_00 = [
# """{
#     "voucher_code":"CUBKB2305",
#     "voucher_promotionid":609008067264512,
#     "signature":"",
#     "signature_source":"3"
#    }"""
# ]

#00:00 9折(1800)[1500]
# voucher_special_00 = [
# """{
#     "voucher_code":"7MJYMEGAAS",
#     "voucher_promotionid":602566060916736,
#     "signature":"",
#     "signature_source":"3"
#    }"""
# ]

voucher_null = [
     """{"voucher_code":"null"}"""
]