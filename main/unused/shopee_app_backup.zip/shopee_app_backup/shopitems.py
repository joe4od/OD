# royal_tech_tw #39304
# shop_special_4 = [
#     """{
#     "unit_price":5980,
#     "merchandise_subtotal":11960,
#     "promocode_applied":2000,
#     "total_payable":9960,
#     "quantity":2,
#     "shopid":6012856,
#     "itemid":11841247090,
#     "modelid":142476005147,
#     "seller_name":"royal_tech_tw",
#     "voucher_type":"platform"
#     }"""
# ]

# hbfun7 #39312
# shop_special_4 = [
#     """{
#     "unit_price":6045,
#     "merchandise_subtotal":12090,
#     "promocode_applied":1814,
#     "total_payable":10276,
#     "quantity":2,
#     "shopid":801461950,
#     "itemid":20522755404,
#     "modelid":191187971664,
#     "seller_name":"hbfun7",
#     "voucher_type":"platform"
#     }"""
# ]

# house_appliance #39312
# shop_special_4 = [
#     """{
#     "unit_price":6880,
#     "merchandise_subtotal":13760,
#     "promocode_applied":2000,
#     "total_payable":11760,
#     "quantity":2,
#     "shopid":768091796,
#     "itemid":23928458594,
#     "modelid":193957948736,
#     "seller_name":"house_appliance",
#     "voucher_type":"platform"
#     }"""
# ]

# royal_tech_tw #39304
# shop_special_4 = [
#     """{
#     "unit_price":5980,
#     "merchandise_subtotal":11960,
#     "promocode_applied":1794,
#     "total_payable":10166,
#     "quantity":2,
#     "shopid":6012856,
#     "itemid":13002358353,
#     "modelid":78008110046,
#     "seller_name":"royal_tech_tw",
#     "voucher_type":"platform"
#     }"""
# ]

# digitalcitytw #39304
# shop_special_4 = [
#     """{
#     "unit_price":5999,
#     "merchandise_subtotal":11998,
#     "promocode_applied":1800,
#     "total_payable":10198,
#     "quantity":2,
#     "shopid":312985917,
#     "itemid":13152015195,
#     "modelid":132354826076,
#     "seller_name":"digitalcitytw",
#     "voucher_type":"platform"
#     }"""
# ]
# shop_special_4 = [
#     """{
#     "unit_price":6090,
#     "merchandise_subtotal":12180,
#     "promocode_applied":1827,
#     "total_payable":10353,
#     "quantity":2,
#     "shopid":312985917,
#     "itemid":13152015195,
#     "modelid":132354826076,
#     "seller_name":"digitalcitytw",
#     "voucher_type":"platform"
#     }"""
# ]
# shop_special_4 = [
#     """{
#     "unit_price":6185,
#     "merchandise_subtotal":12370,
#     "promocode_applied":1856,
#     "total_payable":10514,
#     "quantity":2,
#     "shopid":312985917,
#     "itemid":13152015195,
#     "modelid":132354826076,
#     "seller_name":"digitalcitytw",
#     "voucher_type":"platform"
#     }"""
# ]

# mrtprice #39304
# shop_special_4 = [
#     """{
#     "unit_price":6885,
#     "merchandise_subtotal":6885,
#     "promocode_applied":1000,
#     "total_payable":5885,
#     "quantity":1,
#     "shopid":305177327,
#     "itemid":3561441080,
#     "modelid":183541863558,
#     "seller_name":"mrtprice",
#     "voucher_type":"platform"
#     }"""
# ]

# kasd.mobile #39304
# shop_special_4 = [
#     """{
#     "unit_price":6085,
#     "merchandise_subtotal":12170,
#     "promocode_applied":1826,
#     "total_payable":10344,
#     "quantity":2,
#     "shopid":334668049,
#     "itemid":11659562782,
#     "modelid":67776866479,
#     "seller_name":"kasd.mobile",
#     "voucher_type":"platform"
#     }"""
# ]

# kent1081 #39304
# shop_special_4 = [
#     """{
#     "unit_price":6045,
#     "merchandise_subtotal":12090,
#     "promocode_applied":1814,
#     "total_payable":10276,
#     "quantity":2,
#     "shopid":43765349,
#     "itemid":3616997741,
#     "modelid":155255217220,
#     "seller_name":"kent1081",
#     "voucher_type":"platform"
#     }"""
# ]

# links2020 #39304
# shop_special_4 = [
#     """{
#     "unit_price":6085,
#     "merchandise_subtotal":12170,
#     "promocode_applied":1826,
#     "total_payable":10344,
#     "quantity":2,
#     "shopid":290353018,
#     "itemid":8096604344,
#     "modelid":200716913310,
#     "seller_name":"links2020",
#     "voucher_type":"platform"
#     }"""
# ]

# bearshow3c #39304
# shop_special_4 = [
#     """{
#     "unit_price":5790,
#     "merchandise_subtotal":11580,
#     "promocode_applied":1737,
#     "total_payable":9843,
#     "quantity":2,
#     "shopid":68745283,
#     "itemid":7831859969,
#     "modelid":172756276964,
#     "seller_name":"bearshow3c",
#     "voucher_type":"platform"
#     }"""
# ]

# qek588 #39308
# shop_special_4 = [
#     """{
#     "unit_price":5999,
#     "merchandise_subtotal":11998,
#     "promocode_applied":1800,
#     "total_payable":10198,
#     "quantity":2,
#     "shopid":584227475,
#     "itemid":19419218489,
#     "modelid":155063601223,
#     "seller_name":"qek588",
#     "voucher_type":"platform"
#     }"""
# ]

# shopee24h_el(39010)
# shop_special_4 = [
#     """{
#     "unit_price":23344,
#     "merchandise_subtotal":23344,
#     "promocode_applied":2000,
#     "total_payable":21344,
#     "quantity":1,
#     "shopid":116309859,
#     "itemid":12410213246,
#     "modelid":170864759619,
#     "seller_name":"shopee24h_el",
#     "voucher_type":"platform"
#     }"""
# ]

# shopee24h_el(39010)
# 綠色 170864759619 (145)
# 黑色 130459216608 (10)
# 白色 130459216609 (16)
# 藍色 130459216611 (39)
# 粉色 130459216612 (145)
# 綠色 170864759619 (145)
# shop_special_4 = [
#     """{
#     "unit_price":23188,
#     "merchandise_subtotal":23188,
#     "promocode_applied":1500,
#     "total_payable":21688,
#     "quantity":1,
#     "shopid":116309859,
#     "itemid":12410213246,
#     "modelid":130459216609,
#     "seller_name":"shopee24h_el",
#     "voucher_type":"platform"
#     }"""
# ]

# shop_special_4 = [
#     """{
#     "unit_price":23099,
#     "merchandise_subtotal":23099,
#     "promocode_applied":2000,
#     "total_payable":21099,
#     "quantity":1,
#     "shopid":116309859,
#     "itemid":12410213246,
#     "modelid":130459216609,
#     "seller_name":"shopee24h_el",
#     "voucher_type":"platform"
#     }"""
# ]

# shopee24h_el(39010)
# shop_special_4 = [
#     """{
#     "unit_price":6400,
#     "merchandise_subtotal":12800,
#     "promocode_applied":1920,
#     "total_payable":10880,
#     "quantity":2,
#     "shopid":116309859,
#     "itemid":15608799656,
#     "modelid":132630763095,
#     "seller_name":"shopee24h_el",
#     "voucher_type":"platform"
#     }"""
# ]

# sinya_mkt(39304)
# shop_special_4 = [
#     """{
#     "unit_price":6190,
#     "merchandise_subtotal":12380,
#     "promocode_applied":1857,
#     "total_payable":10523,
#     "quantity":2,
#     "shopid":30296506,
#     "itemid":6128596001,
#     "modelid":113051592800,
#     "seller_name":"sinya_mkt",
#     "voucher_type":"platform"
#     }"""
# ]

# sinya_mkt(39304)
# shop_special_4 = [
#     """{
#     "unit_price":6390,
#     "merchandise_subtotal":12780,
#     "promocode_applied":1917,
#     "total_payable":10863,
#     "quantity":2,
#     "shopid":30296506,
#     "itemid":6128596001,
#     "modelid":113051592800,
#     "seller_name":"sinya_mkt",
#     "voucher_type":"platform"
#     }"""
# ]

# house_appliance(39312)
# shop_special_4 = [
#     """{
#     "unit_price":6290,
#     "merchandise_subtotal":12580,
#     "promocode_applied":1887,
#     "total_payable":10693,
#     "quantity":2,
#     "shopid":768091796,
#     "itemid":21915255413,
#     "modelid":190847512269,
#     "seller_name":"house_appliance",
#     "voucher_type":"platform"
#     }"""
# ]

# tenggou2019(39312) >> 只有超商
# shop_special_4 = [
#     """{
#     "unit_price":6290,
#     "merchandise_subtotal":12580,
#     "promocode_applied":1887,
#     "total_payable":10693,
#     "quantity":2,
#     "shopid":238223058,
#     "itemid":5724589814,
#     "modelid":72513224188,
#     "seller_name":"tenggou2019",
#     "voucher_type":"platform"
#     }"""
# ]

# mrtprice(39304)
# shop_special_4 = [
#     """{
#     "unit_price":6125,
#     "merchandise_subtotal":12250,
#     "promocode_applied":1838,
#     "total_payable":10412,
#     "quantity":2,
#     "shopid":305177327,
#     "itemid":3561441080,
#     "modelid":211791872216,
#     "seller_name":"mrtprice",
#     "voucher_type":"platform"
#     }"""
# ]

# senao.tw(39304)
# 灰 202887691922
# 銀 202887691924
# shop_special_4 = [
#     """{
#     "unit_price":10355,
#     "merchandise_subtotal":10355,
#     "promocode_applied":1554,
#     "total_payable":8801,
#     "quantity":1,
#     "shopid":54598032,
#     "itemid":13041383300,
#     "modelid":202887691924,
#     "seller_name":"senao.tw",
#     "voucher_type":"platform"
#     }"""
# ]

# 白 192209509911
# shop_special_4 = [
#     """{
#     "unit_price":21999,
#     "merchandise_subtotal":21999,
#     "promocode_applied":2000,
#     "total_payable":19999,
#     "quantity":1,
#     "shopid":54598032,
#     "itemid":13010000702,
#     "modelid":77556518764,
#     "seller_name":"senao.tw",
#     "voucher_type":"platform"
#     }"""
# ]

# kent1081(39304)
# shop_special_4 = [
#     """{
#     "unit_price":6125,
#     "merchandise_subtotal":12250,
#     "promocode_applied":1838,
#     "total_payable":10412,
#     "quantity":2,
#     "shopid":43765349,
#     "itemid":3616997741,
#     "modelid":201595090812,
#     "seller_name":"kent1081",
#     "voucher_type":"platform"
#     }"""
# ]

# shopee24h_el(39010)
# 黑 203218277891 (16)
# 紫 203218277888 (31)
# 白 203218277892 (10)
# shop_special_4 = [
#     """{
#     "unit_price":26399,
#     "merchandise_subtotal":26399,
#     "promocode_applied":2000,
#     "total_payable":24399,
#     "quantity":1,
#     "shopid":54598032,
#     "itemid":15195013618,
#     "modelid":203218277888,
#     "seller_name":"shopee24h_el",
#     "voucher_type":"platform"
#     }"""
# ]

# shop_special_4 = [
#     """{
#     "unit_price":8225,
#     "merchandise_subtotal":8225,
#     "promocode_applied":0,
#     "total_payable":8225,
#     "quantity":1,
#     "shopid":54598032,
#     "itemid":11848941828,
#     "modelid":155610723140,
#     "seller_name":"senao.tw",
#     "voucher_type":"platform"
#     }"""
# ]

# links2020 #39304
# shop_special_4 = [
#     """{
#     "unit_price":10500,
#     "merchandise_subtotal":10500,
#     "promocode_applied":1575,
#     "total_payable":8925,
#     "quantity":1,
#     "shopid":290353018,
#     "itemid":13937417920,
#     "modelid":95542235891,
#     "seller_name":"links2020",
#     "voucher_type":"platform"
#     }"""
# ]

# shop_special_4 = [
#     """{
#     "unit_price":7189,
#     "merchandise_subtotal":14378,
#     "promocode_applied":2000,
#     "total_payable":12378,
#     "quantity":2,
#     "shopid":290353018,
#     "itemid":22110810846,
#     "modelid":220488301541,
#     "seller_name":"links2020",
#     "voucher_type":"platform"
#     }"""
# ]

# shopee24h_el #39310
# shop_special_4 = [
#     """{
#     "unit_price":7190,
#     "merchandise_subtotal":14380,
#     "promocode_applied":2000,
#     "total_payable":12380,
#     "quantity":2,
#     "shopid":116309859,
#     "itemid":21260933479,
#     "modelid":107694919523,
#     "seller_name":"shopee24h_el",
#     "voucher_type":"platform"
#     }"""
# ]

# 灰 135193030620
# 銀 135193030618
# shop_special_4 = [
#     """{
#     "unit_price":10288,
#     "merchandise_subtotal":10288,
#     "promocode_applied":1544,
#     "total_payable":8744,
#     "quantity":1,
#     "shopid":116309859,
#     "itemid":16642891634,
#     "modelid":135193030620,
#     "seller_name":"shopee24h_el",
#     "voucher_type":"platform"
#     }"""
# ]

# hp3855905 #39304
# 黃 175713913721
# 藍 175713913723
# 銀 175713913720
# shop_special_4 = [
#     """{
#     "unit_price":14188,
#     "merchandise_subtotal":14188,
#     "promocode_applied":2000,
#     "total_payable":12188,
#     "quantity":1,
#     "shopid":58829559,
#     "itemid":22132095613,
#     "modelid":175713913720,
#     "seller_name":"hp3855905",
#     "voucher_type":"platform"
#     }"""
# ]

# digitalcitytw #39304
# shop_special_4 = [
#     """{
#     "unit_price":10300,
#     "merchandise_subtotal":10300,
#     "promocode_applied":1545,
#     "total_payable":8755,
#     "quantity":1,
#     "shopid":312985917,
#     "itemid":18411472489,
#     "modelid":210650289375,
#     "seller_name":"digitalcitytw",
#     "voucher_type":"platform"
#     }"""
# ]

shop_special_4 = [
    """{
    "unit_price":6649,
    "merchandise_subtotal":6649,
    "promocode_applied":1000,
    "total_payable":5649,
    "quantity":1,
    "shopid":312985917,
    "itemid":23507397688,
    "modelid":203322230117,
    "seller_name":"digitalcitytw",
    "voucher_type":"platform"
    }"""
]

# shop_special_4 = [
#     """{
#     "unit_price":6050,
#     "merchandise_subtotal":12100,
#     "promocode_applied":1815,
#     "total_payable":10285,
#     "quantity":2,
#     "shopid":312985917,
#     "itemid":13152015195,
#     "modelid":132354826076,
#     "seller_name":"digitalcitytw",
#     "voucher_type":"platform"
#     }"""
# ]

# al0w_39zoj #39304
# shop_special_4 = [
#     """{
#     "unit_price":6750,
#     "merchandise_subtotal":6750,
#     "promocode_applied":1000,
#     "total_payable":5750,
#     "quantity":1,
#     "shopid":273587632,
#     "itemid":22428751174,
#     "modelid":203965714108,
#     "seller_name":"al0w_39zoj",
#     "voucher_type":"platform"
#     }"""
# ]

# soking88 #39304
# shop_special_4 = [
#     """{
#     "unit_price":6799,
#     "merchandise_subtotal":6799,
#     "promocode_applied":1000,
#     "total_payable":5799,
#     "quantity":1,
#     "shopid":26661247,
#     "itemid":17391073863,
#     "modelid":203469033493,
#     "seller_name":"soking88",
#     "voucher_type":"platform"
#     }"""
# ]